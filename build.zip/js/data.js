const data = {
    "first_name": "Elizaveta",
    "last_name": "Abramova",
    "job_title": "JUNIOR FRONTEND DEVELOPER",
    "photo": "images/w1.jpg",
    "phone": "+79266292035",
    "email": "elizaveta.abramova@mail.com",
    "address": "Россия, Москва.",
    "skills": [
        "HTML 5",
        "CSS 3",
        "Bootstrap",
        "Git",
        "Gulp",
    ],
    "education": [
        "Medical College №5",
    ],
    "achievements": [
        "I completed the course in a week and I really liked it.",
    ],
    "profile": "I am a front-end engineer developer, I approach my tasks carefully and with enthusiasm. I am looking for an entry-level position to continue to develop in development, use my skills in solving complex problems and help in the timely completion of company projects."
};