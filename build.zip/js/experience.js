const experience = [
    {
        "company": "Hospital at the Presidente",
        "city": "MOSCOW",
        "from": "2017",
        "to": 'Present',
        "position": "Head nurse",
        "description": "<li>Organization of staff work</li> <li>Holding conferences</li> <li>Execution of medical procedures</li>"
    },
    {
        "company": "The Russian Academy of Sciences",
        "city": "MOSCOW",
        "from": "2014",
        "to": '2017',
        "position": "Nurse",
        "description": "<li>Execution of medical procedures</li>"
    }
]